<html lang="fr">
	<head>
	 	<meta charset="utf-8">
		<title>Accueil</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/fond.css">
	</head>
	<body>
		<div class="container-fluid">

			<h2>M2L Manager</h2>	

			<button type="button" class="btn btn-lig"><a href="ligue.php">Ligues</a></button>
			<button type="button" class="btn btn-pres"><a href="prestation.php">Prestations</a></button>
			<button type="button" class="btn btn-fac"><a href="facture.php">Facturation</a></button>	
			<button type="button" class="btn btn-hist"><a href="historiquePrix.php">historique des prix</a></button>

			<script src="https://unpkg.com/@popperjs/core@2.4.0/dist/umd/popper.min.js"></script>
			<script src="js/bootstrap.js"></script>
		</div>
	
	</body>
</html>

<?php
?>