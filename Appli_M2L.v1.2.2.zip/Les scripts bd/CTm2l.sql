GRANT ALL ON m2l . * TO 'm2l'@'localhost' IDENTIFIED BY 'secret';
drop table if exists Ligue;
drop table if exists Prestation;
drop table if exists Facture;
drop table if exists Ligne_Facture;
drop table if exists Historique_des_prix_unitaires;

CREATE TABLE Ligue 
	(
	Compte integer(6) Not NULL AUTO_INCREMENT,
	Intitule Varchar(30)Not NULL,
	Tresorier Varchar(30)Not NULL,
	adresseboo boolean Not NULL,
	adresseecr varchar(50) Not NULL,
	Constraint PK_ligue PRIMARY KEY (Compte)
	)Engine = Innodb;

CREATE TABLE Prestation
	(
	Code Varchar(15)Not NULL,
	Libelle Varchar(30)Not NULL,
	PU decimal(4,3)Not NULL,
	totalTTC decimal(4,3)Not NULL, 
	Constraint PK_prestation PRIMARY KEY (Code)
	)Engine = Innodb;

CREATE TABLE Facture
	(
	Num_facture int(4)Not NULL AUTO_INCREMENT ,
	Compte_Ligue integer(6)Not NULL,
	Ndate Date Not NULL,
	Echeance Date Not NULL,
	Constraint PK_facture PRIMARY KEY (Num_facture)
	)Engine = Innodb;

CREATE TABLE Ligne_Facture
	(
	Num_Facture int(4) Not NULL,
	Code_Prestation Varchar(30) Not NULL,
	Quantite integer(10) Not NULL,
	Constraint PK_lignefacture PRIMARY KEY (Num_Facture, Code_Prestation)
	)Engine = Innodb;

CREATE TABLE Historique_des_prix_unitaires
	(
	code_his varchar(15) Not NULL,
	PUhis decimal(5,4) Not NULL,
	totalTTChis decimal(6,4) Not NULL,
	datutilisationprix date Not NULL,
	Constraint PK_historiquedesprixunitaires PRIMARY KEY (code_his, datutilisationprix)
	)Engine = Innodb;