DELETE FROM Ligue;
Insert Into Ligue (Intitule,Tresorier,adresseboo,adresseecr) Values('Ligue Lorraine Escrime','Valerie LAHEURTE', TRUE, '13 r Jean Moulin 54510 Tomblaine');
Insert Into Ligue (Intitule,Tresorier,adresseboo,adresseecr) Values('Ligue Lorraine de FootBall','Pierre LENOIR', FALSE,'8 r Jean Moulin 54510 Tomblaine');
Insert Into Ligue (Intitule,Tresorier,adresseboo,adresseecr) Values('Ligue Lorraine de Basket','Mohamed BOURGARD', FALSE, '10 r Jean Moulin 54510 Tomblaine');
Insert Into Ligue (Intitule,Tresorier,adresseboo,adresseecr) Values('Ligue Lorraine de Baby-foot','Sylvain DELAHOUSSE', TRUE,'19 r Jean Moulin 54510 Tomblaine');
SELECT * from Ligue;

DELETE FROM Prestation;
Insert Into Prestation Values('AFFRAN','Affranchissement','3.33',PU*1.2);
Insert Into Prestation Values('PHOTOCOULEUR','Photocopies couleur','0.24',PU*1.2);
Insert Into Prestation Values('PHOTONB','Photocopies Noir et Blanc','0.055',PU*1.2);
Insert Into Prestation Values('TRACEUR','Utilisation du traceur','0.356',PU*1.2);
SELECT * from Prestation;

DELETE FROM Facture;
Insert Into Facture Values(5175,411007,'2012-12-02','2012-02-29');
Insert Into Facture Values(5174,411010,'2013-01-12','2013-01-31');
SELECT * from Facture;

DELETE FROM Ligne_Facture;
Insert Into Ligne_Facture Values(5174,'AFFRAN',1);
Insert Into Ligne_Facture Values(5174,'PHOTOCOULEUR',166);
Insert Into Ligne_Facture Values(5174,'PHOTONB',889);
Insert Into Ligne_Facture Values(5175,'PHOTOCOULEUR',300);
Insert Into Ligne_Facture Values(5175,'PHOTONB',522);
Insert Into Ligne_Facture Values(5175,'TRACEUR',2);
SELECT * from Ligne_Facture;

DELETE FROM Historique_des_prix_unitaires;
Insert Into Historique_des_prix_unitaires Values('AFFRAN','6.66',PUhis*1.2,'2019-03-05');
Insert Into Historique_des_prix_unitaires Values('AFFRAN','1.665',PUhis*1.2,'2017-03-05');
Insert Into Historique_des_prix_unitaires Values('PHOTOCOULEUR','0.48',PUhis*1.2,'2019-03-05');
Insert Into Historique_des_prix_unitaires Values('PHOTOCOULEUR','0.12',PUhis*1.2,'2017-03-05');
Insert Into Historique_des_prix_unitaires Values('PHOTONB','0.11',PUhis*1.2,'2019-03-05');
Insert Into Historique_des_prix_unitaires Values('PHOTONB','0.0275',PUhis*1.2,'2017-03-05');
Insert Into Historique_des_prix_unitaires Values('TRACEUR','0.712',PUhis*1.2,'2019-03-05');
Insert Into Historique_des_prix_unitaires Values('TRACEUR','0.178',PUhis*1.2,'2017-03-05');
SELECT * from Historique_des_prix_unitaires;
