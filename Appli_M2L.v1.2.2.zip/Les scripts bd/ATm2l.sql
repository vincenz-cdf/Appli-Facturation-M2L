ALTER Table Facture
ADD CONSTRAINT FK_FAC_TYP FOREIGN KEY (Compte_Ligue) REFERENCES Ligue (Compte);

ALTER Table Ligne_Facture 
ADD CONSTRAINT FK_LFAC1_TYP FOREIGN KEY (Num_Facture) REFERENCES Facture (Num_Facture);

ALTER Table Ligne_Facture
ADD CONSTRAINT FK_LFAC2_TYP FOREIGN KEY (Code_Prestation) REFERENCES Prestation (Code);

ALTER Table Historique_des_prix_unitaires
ADD CONSTRAINT FK_HPU_TYP FOREIGN KEY (Code_his) REFERENCES Prestation (Code);

ALTER TABLE Facture AUTO_INCREMENT = 5174;
ALTER TABLE ligue AUTO_INCREMENT = 411007;